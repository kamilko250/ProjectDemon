#!/bin/bash

mkdir -p ~/DAEMON/kat1/folder/kolejny/inny
mkdir -p ~/DAEMON/kat2
mkdir -p ~/DAEMON/kat1/folder/kolejny/znowu
mkdir -p ~/DAEMON/kat1/folder/kolejny/jeszczeinny
mkdir -p ~/DAEMON/kat1/folder2/cat13
mkdir -p ~/DAEMON/kat1/folder2/cat15
mkdir -p ~/DAEMON/kat1/folder3/directory/katalog

echo "tekst" > ~/DAEMON/kat1/folder/plik.txt
echo "cos innego" > ~/DAEMON/kat1/folder/plik2.txt
echo "abcd" > ~/DAEMON/kat1/folder/kolejny/file.txt
echo "fdsa" > ~/DAEMON/kat1/folder/kolejny/znowu/plik123.txt
echo "bardzo mocno" > ~/DAEMON/kat1/folder/kolejny/jeszczeinny/iuy.txt
echo "dobry projekt" > ~/DAEMON/kat1/folder/kolejny/jeszczeinny/utyas.txt
echo "nowy" > ~/DAEMON/kat1/folder2/file544.txt
echo "polnoc" > ~/DAEMON/kat1/folder2/cat13/intrax.txt
echo "helloworld" > ~/DAEMON/kat1/folder2/cat15/pliknowy.txt
echo "studia" > ~/DAEMON/kat1/folder3/plik.txt
echo "demo" > ~/DAEMON/kat1/folder3/directory/trial.txt
echo "witajcie" > ~/DAEMON/kat1/folder3/directory/katalog/pliczek.txt

echo "utworzono strukture katalogow"


